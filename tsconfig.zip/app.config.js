const appJson = require('./app.json');

/** Merges `app.json` with runtime config (API URL from env). */
module.exports = {
  expo: {
    ...appJson.expo,
    extra: {
      ...(appJson.expo.extra ?? {}),
      apiBaseUrl: process.env.EXPO_PUBLIC_API_BASE_URL ?? '',
    },
  },
};
